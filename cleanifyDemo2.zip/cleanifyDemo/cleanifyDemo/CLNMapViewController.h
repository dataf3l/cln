//
//  CLNMapViewController.h
//  cleanifyDemo
//
//  Created by Dvid Silva on 6/16/15.
//  Copyright © 2015 Cleanify. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLNPurchaseOrder.h"
@interface CLNMapViewController : UIViewController
@property(strong,nonatomic) CLNPurchaseOrder* purchaseOrder;

@end
